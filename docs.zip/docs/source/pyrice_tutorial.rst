Tutorial
========

Using the multi_query module
----------------------------

The most important module in the PyRice package is the :py:mod:`~pyrice.multi_query` module.
And :py:class:`~pyrice.multi_query.MultiQuery` class in :py:mod:`~pyrice.multi_query` module use for query informations of gene in many databases.
You can create instances of this class in several ways.

Search gene on chromosome
^^^^^^^^^^^^^^^^^^^^^^^^^

To search gene on chromosome, use the :py:func:`~pyrice.multi_query.MultiQuery.search_gene` function
in the :py:class:`~pyrice.multi_query.MultiQuery` class::

    >>> from pyrice.multi_query import MultiQuery

    >>> query = MultiQuery()
    >>> result = query.search_on_chromosome(chro="chr01", start_pos="1", end_pos="20000",
    				            number_process = 4, dbs="all", save_path="./result/")

If successful, this function returns an :py:class:`dictionary`.
You can set path `save_path` to save data below on file csv::

    >>> print("Output database:", result)
   Output database:
   {'OsNippo01g010050': {
        'msu7Name': {'LOC_Os01g01010'},
        'raprepName': {'Os01g0100100'},
        'contig': 'chr01', 'fmin': 2982,
        'fmax': 10815},
    'OsNippo01g010150': {
        'msu7Name': {'LOC_Os01g01019'},
        'raprepName': {'Os01g0100200'},
        'contig': 'chr01',
        'fmin': 11217,
        'fmax': 12435},
    ...
    'OsNippo01g010300': {
        'msu7Name': {'LOC_Os01g01040'},
        'raprepName': {'Os01g0100500'},
        'contig': 'chr01',
        'fmin': 16398,
        'fmax': 20144}
    }

Search informations gene using chromosome
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

PyRice package support searching follow start and end position of gene on chromosome. Use the :py:func:`~pyrice.MultiQuery.query_by_chromosome` function in the :py:class:`~pyrice.multi_query.MultiQuery` class::

	>>> from pyrice.multi_query import MultiQuery

	>>> query = MultiQuery()
	>>> result = query.query_by_chromosome(chro="chr01", start_pos="1", end_pos="20000", 
				               number_process = 4, multi_processing=True,
		                               multi_threading=True, dbs="all")

If successful, this function returns an :py:class:`dictionary`. ::

	>>> print("Output database:", result)
	Output database:
	{'OsNippo01g010050': {
	    'rapdb': {
	        'Locus_ID': 'Os01g0100100',
	        'Description': 'RabGAP/TBC domain containing protein.',
                'Oryzabase Gene Name Synonym(s)': 'Molecular Function: Rab GTPase activator activity (GO:0005097)',
                ...},
            'gramene': {
                '_id': 'Os01g0100100',
                'name': 'Os01g0100100',
                'biotype': 'protein_coding',
                ...},
            ...},
        'OsNippo01g010150': {
            'rapdb': {...},
            'gramene': {...},
            ...},
        ...
        }

To save the result, package use the :py:func:`~pyrice.multi_query.MultiQuery.save` function in the :py:class:`~pyrice.multi_query.MultiQuery` with 4 types of file html, pkl, json, csv.::

    >>> query.save(result, save_path="./result/",
                   format=["csv", "html", "json", "pkl"], hyper_link=False)

Search informations gene using id, loc or iricname
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

PyRice packgae support searching follow 3 identification of gene: id on Oryzabase, locus on MSU and iricname on SNP-SEEK. Use the :py:func:`~pyrice.multi_query.MultiQuery.query_by_ids` function in the :py:class:`~pyrice.multi_query.MultiQuery` class::

	>>> query = MultiQuery()

	>>> result = query.query_by_ids(ids=["Os08g0164400", "Os07g0586200"],
                                        locs=["LOC_Os10g01006", "LOC_Os07g39750"],
                                        irics=["OsNippo01g010050", "OsNippo01g010300"],
                                        number_process = 4, multi_processing=True, multi_threading=True, dbs="all")

If successful, this function returns an :py:class:`dictionary`.::

	>>> print("Output database:",result)
	Output database:
	{'OsNippo01g010050': {
            'rapdb': {
                'Locus_ID': 'Os01g0100100',
                'Description': 'RabGAP/TBC domain containing protein.',
                'Position': '',
                ...},
            'ic4r': {
                'Anther_Normal': {'expression_value': '0.699962'},
                'Anther_WT': {'expression_value': '13.9268'},
                ...},
            ...},
        'OsNippo01g010300': {
            'rapdb': {...},
            'ic4r': {...},
            ...},
        ...
        }
    
To save the result, package use the :py:func:`~pyrice.multi_query.MultiQuery.save` function in the :py:class:`~pyrice.multi_query.MultiQuery` with 4 types of file html, pkl, json, csv.::

	>>> query.save(result, save_path = "./result/",
	               format=["csv", "html", "json", "pkl"], hyper_link=False)

Search new attributes on new databases
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
PyRice package support query on new databases by add it on file `database_description.xml`. Use the :py:func:`~pyrice.multi_query.MultiQuery.query_new_databse` function in the :py:class:`~pyrice.multi_query.MultiQuery` class::

	>>> query = MultiQuery()

	>>> result = query.query_new_database(atts=['TRAES3BF001000010CFD'], number_process= 4,
                                              multi_processing=True,multi_threading=True,dbs=['urgi'])

If successful, this function returns an :py:class:`dictionary`.::

    >>> print("Output database:",result)
    Output database:
    {'TRAES3BF001000010CFD':
        {'urgi':{
            'recordsTotal': 1177800,
            'recordsFiltered': 1177800,
            'draw': None,
            ...}
        }
    }


To save the result, package use the :py:func:`~pyrice.multi_query.MultiQuery.save` function in the :py:class:`~pyrice.multi_query.MultiQuery` with 4 types of file html, pkl, json, csv.::

    >>> query.save(result, save_path="./result/",
                   format=["csv", "html", "json", "pkl"], hyper_link=False)


Using the build_dictionary module
---------------------------------

PyRice package save 2 databases: Oryzabase and Rap ; 3 dictionaries identifications of gene.
So, it has functions to update regularly gene use the :py:func:`~pyrice.build_dictionary.update_gene_dictionary` function
and :py:func:`~pyrice.build_dictionary.update_rapdb_oryzabase` function in the :py:mod:`~pyrice.build_dictionary` module::

    >>> from pyrice.build_dictionary import update_gene_dictionary, update_rapdb_oryzabase

    >>> update_gene_dictionary()
    >>> update_rapdb_oryzabase(rapdb_url, oryzabase_url)

Using the utils module
----------------------

PyRice package has 1 function to search text on result after using query functions.
Use the :py:func:`~pyrice.utils.search` function in the :py:mod:`~pyrice.utils` module::

    >>> from pyrice.utils import search
    >>> import pandas as pd

    >>> df1 = pd.read_pickle("./result1/data/db.pkl")
    >>> df2 = pd.read_pickle("./result2/data/db.pkl")
    >>> df = pd.concat([df1,df2])
    >>> result = search(df,"Amino acid ")

.. note:: You have to save file as pkl and load file again to using :py:func:`~pyrice.utils.search` function.

Structure of file database wrapper
-------------------------------------

PyRice package has 1 file database wrapper (database_description.xml) to manager all infomations of database::

    <database dbname="name of the database" type="Type of the response" method="GET or POST">
        <link stern="the link section before the query" aft="section behind the query"/>
        <headers>
            <header type="">Column number 1</header>
            <header type="">Column number 2</header>
            etc.
        </headers>
        <fields>
            <field>Query argument number 1</field>
        </fields>
        <data_struct indicator="indicator of return data segment" identifier="the attribute to identify data section" identification_string="value of said identifier" line_separator="indicator of a line of data" cell_separator="indicator of a cell of data"/>
        <prettify>Regular expression of unwanted character</prettify>
    </database>

Example: here is a Oryzabase database::

    <database dbname="oryzabase" type="text/html" method="POST">
        <link stern="https://shigen.nig.ac.jp/rice/oryzabase/gene/advanced/list"/>
        <headers>
            <header type="">CGSNL Gene Symbol</header>
            <header type="">Gene symbol synonym(s)</header>
            <header type="">CGSNL Gene Name</header>
            <header type="">Gene name synonym(s)</header>
            <header type="">Chr. No.</header>
            <header type="">Trait Class</header>
            <header type="">Gene Ontology</header>
            <header type="">Trait Ontology</header>
            <header type="">Plant Ontology</header>
            <header type="">RAP ID</header>
            <header type="">Mutant Image</header>
        </headers>
        <fields>
            <field>rapId</field>
        </fields>
        <data_struct indicator="table" identifier="class" identification_string="table_summery_list table_nowrapTh max_width_element" line_separator="tr" cell_separator="td"/>
        <prettify>\n>LOC_.*\n|\n|\r|\t</prettify>
    </database>


