Installation
============

Pip installation
----------------

Install Pillow with :command:`pip`::

    $ pip install Pillow


Github installation
-------------------

Clone project on PyRice with :command:`git`::

  $git clone https://github.com/SouthGreenPlatform/PyRice.git


Building from source
--------------------

Download and extract the `compressed archive from PyPI`_.

.. _compressed archive from PyPI: https://test.pypi.org/project/pyrice/

