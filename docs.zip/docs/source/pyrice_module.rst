Pyrice module
=============

pyrice.build\_dictionary module
-------------------------------

.. automodule:: pyrice.build_dictionary
    :members:
    :undoc-members:
    :show-inheritance:

pyrice.multi\_query module
--------------------------

.. automodule:: pyrice.multi_query
    :members:
    :undoc-members:
    :show-inheritance:

pyrice.utils module
-------------------

.. automodule:: pyrice.utils
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: pyrice
    :members:
    :undoc-members:
    :show-inheritance:
